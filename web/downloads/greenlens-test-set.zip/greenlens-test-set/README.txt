GreenLens — held-out test images
=================================

380 leaf images (10 per class, 38 classes) taken from the project's test split.
The model never saw these images during training, and they were not used to
choose the model. File names are numbers, so the test is blind.

How to test:
1. Open https://amr-elgharip2006.github.io/Plant-Disease-Classification/
2. In "Test a whole set", select all images in images/ together with answers.csv.
3. The site classifies every image and reports the accuracy against answers.csv.
   (You can also upload images one by one and compare with answers.csv.)

answers.csv columns: file, class_id (PlantVillage folder), plant, condition,
plant_ar, condition_ar.

---------------------------------

صور اختبار GreenLens
380 صورة ورقة نبات (10 من كل فئة من 38 فئة) من بيانات الاختبار الخاصة بالمشروع.
الموديل لم يرَ هذه الصور أثناء التدريب، ولم تُستخدم في اختيار الموديل.
أسماء الملفات أرقام فقط، فالاختبار أعمى.

طريقة الاختبار:
1. افتح الموقع: https://amr-elgharip2006.github.io/Plant-Disease-Classification/
2. في قسم "اختبر مجموعة صور" اختر كل الصور من فولدر images ومعاها ملف answers.csv.
3. الموقع يحلل كل الصور ويحسب الدقة بالمقارنة مع answers.csv.
